package com.mitocode.service;

import com.mitocode.model.Empleados;
import com.mitocode.model.Exam;

public interface IEmpleadoService extends ICRUD<Empleados, Integer>{
}
