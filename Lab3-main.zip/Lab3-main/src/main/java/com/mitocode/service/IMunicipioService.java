package com.mitocode.service;

import com.mitocode.model.Jugador;
import com.mitocode.model.Municipios;
import java.util.List;

public interface IMunicipioService extends ICRUD<Municipios,Integer>{
}
