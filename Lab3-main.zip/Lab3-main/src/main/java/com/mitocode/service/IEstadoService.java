package com.mitocode.service;

import com.mitocode.model.Estado;

public interface IEstadoService extends ICRUD<Estado,Integer>{
}
