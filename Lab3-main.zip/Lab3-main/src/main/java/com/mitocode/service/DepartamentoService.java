package com.mitocode.service;

import com.mitocode.model.Camisa;
import com.mitocode.model.Departamentos;

public interface DepartamentoService extends ICRUD<Departamentos, Integer>{
}
