package com.mitocode.service;


import com.mitocode.model.Posicion;

public interface IPosicionService extends ICRUD<Posicion, Integer>{

}
