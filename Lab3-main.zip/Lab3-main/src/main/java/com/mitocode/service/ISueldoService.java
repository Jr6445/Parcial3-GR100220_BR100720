package com.mitocode.service;

import com.mitocode.model.Municipios;
import com.mitocode.model.Sueldo;

public interface ISueldoService extends ICRUD<Sueldo,Integer>{
}
