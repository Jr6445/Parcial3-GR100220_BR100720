package com.mitocode.service;


import com.mitocode.model.Camisa;

public interface ICamisaService extends ICRUD<Camisa, Integer>{

}