package com.mitocode.repo;


import com.mitocode.model.Camisa;
import com.mitocode.model.Posicion;

public interface IPosicionRepo extends IGenericRepo<Posicion, Integer>{

}