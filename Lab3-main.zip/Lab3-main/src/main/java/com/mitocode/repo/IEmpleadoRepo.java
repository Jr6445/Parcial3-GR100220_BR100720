package com.mitocode.repo;

import com.mitocode.model.Empleados;
import com.mitocode.model.Exam;

public interface IEmpleadoRepo extends IGenericRepo<Empleados, Integer>{
}
