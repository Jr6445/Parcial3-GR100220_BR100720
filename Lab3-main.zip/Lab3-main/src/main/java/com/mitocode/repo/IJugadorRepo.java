package com.mitocode.repo;

import com.mitocode.model.Jugador;

public interface IJugadorRepo extends IGenericRepo<Jugador, Integer>{
}
