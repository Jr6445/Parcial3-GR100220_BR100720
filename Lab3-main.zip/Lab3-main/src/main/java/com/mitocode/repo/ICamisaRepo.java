package com.mitocode.repo;


import com.mitocode.model.Camisa;
import com.mitocode.model.Jugador;

public interface ICamisaRepo extends IGenericRepo<Camisa, Integer>{
}