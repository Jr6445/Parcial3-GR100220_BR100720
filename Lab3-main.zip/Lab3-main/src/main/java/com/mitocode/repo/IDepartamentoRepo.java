package com.mitocode.repo;

import com.mitocode.model.Departamentos;
import com.mitocode.model.Exam;

public interface IDepartamentoRepo extends IGenericRepo<Departamentos, Integer>{
}
