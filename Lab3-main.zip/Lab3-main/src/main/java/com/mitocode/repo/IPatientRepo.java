package com.mitocode.repo;

import com.mitocode.model.Patient;

//@Repository
public interface IPatientRepo extends IGenericRepo<Patient, Integer> {
}
