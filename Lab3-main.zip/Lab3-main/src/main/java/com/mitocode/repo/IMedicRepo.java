package com.mitocode.repo;

import com.mitocode.model.Medic;

public interface IMedicRepo extends IGenericRepo<Medic, Integer> {
}
